<?php

$connect = mysqli_connect(
    // 'sql309.epizy.com',
    // 'epiz_31414988',
    // 'PaT9wFliRt72gef',
    // 'epiz_31414988_portfolioNew'
    'sql203.epizy.com',
    'epiz_31641788',
    '0LsRZT1gaRMOXlr',
    'epiz_31641788_portfolio'
);

mysqli_set_charset( $connect, 'UTF8' );
