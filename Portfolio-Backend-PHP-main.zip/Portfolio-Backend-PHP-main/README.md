Create database from .sql file located in [database folder](database)

Download wideImage package from http://wideimage.sourceforge.net/download/, click on 'download it' link and select the library package. Rename the downloaded folder as 'wideimage' and place it inside [includes folder](admin/includes).
